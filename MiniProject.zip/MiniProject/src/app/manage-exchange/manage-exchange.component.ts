import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-exchange',
  templateUrl: './manage-exchange.component.html',
  styleUrls: ['./manage-exchange.component.css']
})
export class ManageExchangeComponent implements OnInit {
  kuchbhi:any;
  constructor() { }

  ngOnInit(): void {
let action = window.localStorage.getItem('item1');

 this.kuchbhi = JSON.parse(action);
console.log(this.kuchbhi);
     
    console.log("ManageExchangeComponent !!!!!!!!!!!!!!!!!");
  }





  
}

